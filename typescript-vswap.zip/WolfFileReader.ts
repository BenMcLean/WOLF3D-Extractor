import fs, { PathLike, Stats } from "fs";
import { CarmackFlag } from "./compression";
import WolfBuffer from "./WolfBuffer";

class WolfFileReader {
	position: number | null;
	readonly path: PathLike;
	
	private fd: number | null;
	private _stats?: Stats;
	
	constructor(path: PathLike) {
		this.path = path;
		this.reopen();
	};
	
	readByte = async (byteLength: number = 1): Promise<number> => {
		const buffer = Buffer.alloc(byteLength);
		if (this.position == null) {
			this.position = 0;
		}
		return new Promise<number>((resolve, reject) => {
			fs.read(this.fd, buffer, 0, byteLength, this.position, (err) => {
				if (err) {
					reject(err);
					return;
				}
				this.position += byteLength;
				resolve(buffer.readUIntLE(0, byteLength));
			});
		});
	};
	
	readWord = async (): Promise<number> => (this.readByte(2));
	readDWord = async (): Promise<number> => (this.readByte(4));
	
	readBuffer = async (num: number, byteLength: number = 1, buffer?: Buffer | WolfBuffer): Promise<WolfBuffer> => {
		const size = num * byteLength;
		buffer = buffer || Buffer.alloc(size);
		const wrap = !(buffer instanceof WolfBuffer);
		const realBuffer = (wrap ? buffer : buffer.buffer) as Buffer;
		if (this.position == null) {
			this.position = 0;
		}
		return new Promise<WolfBuffer>((resolve, reject) => {
			fs.read(this.fd, realBuffer, 0, size, this.position, (err) => {
				if (err) {
					reject(err);
					return;
				}
				this.position += size;
				resolve(wrap ? new WolfBuffer(buffer as Buffer) : buffer as WolfBuffer);
			});
		});
	};
	
	readBytes = async (num: number, byteLength: number = 1, buffer?: Buffer | WolfBuffer): Promise<number[]> => {
		const buf = await this.readBuffer(num, byteLength, buffer);
		return buf.readBytes(0, num, byteLength);
	};
	
	readWords = async (num: number): Promise<number[]> => (this.readBytes(num, 2));
	readDWords = async (num: number): Promise<number[]> => (this.readBytes(num, 4));
	
	readCarmackExpanded = async (): Promise<number[]> => {
		let ch, chhigh, count, offset, index;
		
		// First word is expanded length
		let length = await this.readWord();
		let expandedWords: number[] = []; // array of WORDS
		
		length /= 2;
		
		index = 0;
		
		while (length > 0) {
			ch = await this.readWord();
			chhigh = ch >> 8;
			
			if (chhigh == CarmackFlag.NEAR) {
				count = (ch & 0xFF);
				
				if (count == 0) {
					ch |= await this.readByte();
					expandedWords[index++] = ch;
					length--;
				} else {
					offset = await this.readByte();
					length -= count;
					if (length < 0) {
						return expandedWords;
					}
					while ((count--) > 0) {
						expandedWords[index] = expandedWords[index - offset];
						index++;
					}
				}
			} else if (chhigh == CarmackFlag.FAR) {
				count = (ch & 0xFF);
				
				if (count == 0) {
					ch |= await this.readByte();
					expandedWords[index++] = ch;
					length--;
				} else {
					offset = await this.readWord();
					length -= count;
					if (length < 0) {
						return expandedWords;
					}
					while ((count--) > 0) {
						expandedWords[index++] = expandedWords[offset++];
					}
				}
			} else {
				expandedWords[index++] = ch;
				length--;
			}
		}
		
		return expandedWords;
	};
	
	get stats(): Stats {
		if (this._stats) {
			return this._stats;
		}
		this._stats = fs.statSync(this.path);
		return this._stats;
	}
	
	get fileSize(): number {
		return this.stats.size;
	}
	
	reopen = () => {
		if (this.fd != null) {
			return;
		}
		this.reset();
		this._stats = null;
		this.fd = fs.openSync(this.path, "r");
	};
	
	reset = () => {
		this.position = null;
	};
	
	close = () => {
		fs.close(this.fd, () => {});
		this.fd = null;
	};
}

export default WolfFileReader;
