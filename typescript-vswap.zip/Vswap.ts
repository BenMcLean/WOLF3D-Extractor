export type GraphicChunkMeta = {
	type: "wall" | "sprite",
	width: number,
	height: number,
};

export type GraphicChunk = {
	bitmap?: ImageBitmap,
	meta: GraphicChunkMeta,
	url?: string,
};

export interface Vswap {
	chunks: GraphicChunk[],
	/** release resources. */
	close(): void,
	spritePageOffset: number,
}

export interface VswapWorkerResult {
	chunks: GraphicChunk[],
	spritePageOffset: number,
	transferables: any[];
}
