import { Canvas } from "canvas";
import { AppCanvas } from "../../../util/canvases";
import { GraphicChunk, GraphicChunkMeta, VswapWorkerResult } from "./Vswap";
import { VswapHeader, VswapIngestor, VswapIngestorConfig } from "./VswapFileReader";

class DefaultVswapIngestor implements VswapIngestor<VswapWorkerResult> {
	private chunks: GraphicChunk[];
	private transferables: any[];
	private spritePageOffset: number;
	
	getConfig = (): VswapIngestorConfig => ({ transparentAlpha: 0 });
	
	onInit = (header: VswapHeader): void => {
		this.chunks = Array(header.soundPageOffset - 1);
		this.spritePageOffset = header.spritePageOffset;
		this.transferables = [];
	};
	
	accept = async (canvas: AppCanvas, pageIndex: number, meta: GraphicChunkMeta): Promise<void> => {
		let bitmap: ImageBitmap;
		if (process.env.NODE_ENV !== "test") { // 🐌 for some reason, convertToBlob is extremely slow in worker context, so create image bitmap, then convert to blob in main thread.
			bitmap = await (canvas as OffscreenCanvas).transferToImageBitmap();
		} else {
			bitmap = await createImageBitmap((canvas as Canvas).getContext("2d").getImageData(0, 0, meta.width, meta.height));
		}
		this.chunks[pageIndex] = { bitmap, meta };
		this.transferables.push(bitmap);
	};
	
	onComplete = async (): Promise<VswapWorkerResult> => {
		const { chunks, spritePageOffset, transferables } = this;
		return {
			chunks,
			spritePageOffset,
			transferables
		};
	}
}

export default DefaultVswapIngestor;
