export enum CarmackFlag {
	NEAR = 0xA7,
	FAR = 0xA8,
}

const rlewExpand = (carmackExpanded: number[], length: number, tag: number): number[] => {
	const rawData: number[] = [];
	let srcIndex = 1;
	let destIndex = 0;
	
	let value, count;
	do {
		value = carmackExpanded[srcIndex++];
		if (value !== tag) {
			rawData[destIndex++] = value;
		} else {
			count = carmackExpanded[srcIndex++];
			value = carmackExpanded[srcIndex++];
			for (let i = 1; i <= count; i++) {
				rawData[destIndex++] = value;
			}
		}
	} while(destIndex < length);
	
	return rawData;
};

export {
	rlewExpand,
};
