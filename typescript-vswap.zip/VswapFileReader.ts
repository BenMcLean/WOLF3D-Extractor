import { PathLike } from "fs";
import { AppCanvas, newCanvas } from "../../../util/canvases";
import { Palette, RGBTuple } from "../palettes";
import WolfBuffer from "../WolfBuffer";
import WolfFileReader from "../WolfFileReader";
import { GraphicChunkMeta } from "./Vswap";

const memoSqrt: { [n: number]: number, sqrt: Function } = {
	sqrt: (num: number): number => {
		return num in memoSqrt ? memoSqrt[num] : (memoSqrt[num] = Math.sqrt(num));
	},
};

export type VswapHeader = {
	numChunks: number,
	spritePageOffset: number,
	soundPageOffset: number,
	pageOffsets: number[],
	pageLengths: number[],
	calculated: {
		maxPageLength: number,
		maxPageWidth: number,
		maxPageHeight: number,
	}
};

export type VswapIngestorConfig = {
	transparentColor?: RGBTuple | "palette",
	transparentAlpha?: number,
};

export interface VswapIngestor<R> {
	getConfig(): VswapIngestorConfig,
	onInit(header: VswapHeader): void,
	accept(canvas: AppCanvas, pageIndex: number, meta: GraphicChunkMeta): Promise<void>,
	onComplete(): Promise<R>,
}

class VswapFileReader {
	constructor(
		private readonly path: PathLike,
		private palette: Palette
	) { }
	
	getData = async <T>(ingestor: VswapIngestor<T>): Promise<T> => {
		const config = ingestor.getConfig() || {};
		const vfr = new WolfFileReader(this.path);
		
		// parse header info
		const [ chunks, spritePageOffset, soundPageOffset ] = await vfr.readWords(3);
		const graphicChunks = soundPageOffset;
		let dataStart;
		
		const pageOffsets = await vfr.readDWords(chunks);
		for (let x = 0; x < pageOffsets.length; x++) {
			if (x == 0) {
				dataStart = pageOffsets[0];
			}
			if (pageOffsets[x] != 0 && (pageOffsets[x] < dataStart || pageOffsets[x] > vfr.fileSize)) {
				throw new Error(`VSWAP file '${vfr.path}' contains invalid page offsets.`);
			}
		}
		const pageLengths = await vfr.readWords(chunks);
		const maxPageLength = Math.max(...pageLengths);
		const maxPageWidth = Math.ceil(memoSqrt.sqrt(maxPageLength));
		const maxPageHeight = maxPageWidth;
		
		const canvas = newCanvas(maxPageWidth, maxPageHeight);
		const pageBuffer = new WolfBuffer(Buffer.alloc(maxPageLength));
		const twoD = canvas.getContext("2d") as OffscreenCanvasRenderingContext2D;

		let page;
		
		ingestor.onInit({
			numChunks: chunks,
			spritePageOffset,
			soundPageOffset,
			pageOffsets,
			pageLengths,
			calculated: {
				maxPageLength,
				maxPageWidth,
				maxPageHeight,
			},
		});
		
		// read walls
		for (page = 0; page < spritePageOffset; page++) {
			vfr.position = pageOffsets[page];
			const pageLength = pageLengths[page];
			await vfr.readBuffer(pageLengths[page], 1, pageBuffer);
			
			const width = memoSqrt.sqrt(pageLength);
			const height = width;
			const imgData = twoD.getImageData(0, 0, width, height);
			const data = imgData.data;
			
			const bytes = pageBuffer.readBytes(0, pageLength);
			for (let col = 0, z = 0; col < width; col++) {
				for (let row = 0; row < height; row++, z += 4) {
					const palIdx = bytes[width * row + col];
					const [r, g, b] = this.palette[palIdx];
					data[z] = r;
					data[z + 1] = g;
					data[z + 2] = b;
					data[z + 3] = 255;
				}
			}
			
			twoD.putImageData(imgData, 0, 0);
			await ingestor.accept(canvas, page, { type: "wall", width, height });
		}
		
		const [tr, tg, tb] = config.transparentColor != null && config.transparentColor !== "palette"
			? config.transparentColor : this.palette[this.palette.length - 1];
		const transparentRGBAArray = [tr, tg, tb, config.transparentAlpha != null ? config.transparentAlpha : 255];
		
		// read sprites
		for ( ; page < graphicChunks; page++) {
			const pageLength = pageLengths[page];
			const width = memoSqrt.sqrt(4096); // TODO: dynamic sprite page sizes?
			const height = width;

			vfr.position = pageOffsets[page];
			pageBuffer.buffer.fill(0);
			await vfr.readBuffer(pageLength, 1, pageBuffer);

			let [leftPix, rightPix] = pageBuffer.readWords(0, 2);
			const totalColumns = rightPix - leftPix + 1;
			const colDataOfs = pageBuffer.readWords(pageBuffer.position, totalColumns);
			let pixelIdx = totalColumns * 2 + 4;

			const imgData = twoD.getImageData(0, 0, width, height);
			const data = imgData.data;

			for (let i = 0; i < data.length; i += 4) {
				data.set(transparentRGBAArray, i);
			}

			let startY, endY, newStart;
			for (let spot = 0; leftPix <= rightPix; leftPix++, spot++) {
				let pos = colDataOfs[spot];
				while ((endY = pageBuffer.readWord(pos)) !== 0) {
					endY >>= 1;
					[newStart, startY] = pageBuffer.readWords(pageBuffer.position, 2);
					startY >>= 1;
					pos = pageBuffer.position;

					for ( ; startY < endY; startY++, pixelIdx++) {
						const palIdx = pageBuffer.readByte(pixelIdx, 1);
						const [r, g, b] = this.palette[palIdx];
						const z = (startY * width * 4) + leftPix * 4; // * 4 since data buffer is RGBA expanded out
						data[z] = r;
						data[z + 1] = g;
						data[z + 2] = b;
						data[z + 3] = 255;
					}
				}
			}

			twoD.putImageData(imgData, 0, 0);
			await ingestor.accept(canvas, page, { type: "sprite", width, height });
		}
		
		return ingestor.onComplete();
	};
}

export default VswapFileReader;
