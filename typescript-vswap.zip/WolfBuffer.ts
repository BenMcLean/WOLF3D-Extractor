class WolfBuffer {
	private _position: number = 0;
	
	constructor(readonly buffer: Buffer) {}
	
	readByte = (position: number, byteLength: number = 1) => {
		this._position = position + byteLength;
		return this.buffer.readUIntLE(position, byteLength);
	};
	
	readWord = (position: number) => (this.readByte(position, 2));
	readDWord = (position: number) => (this.readByte(position, 4));
	
	readBytes = (position: number, num: number, byteLength: number = 1): number[] => {
		const arr: number[] = [];
		for (let x = 0; x < num; x++) {
			arr.push(this.readByte(position, byteLength));
			position += byteLength;
		}
		return arr;
	};
	
	readWords = (position: number, num: number): number[] => (this.readBytes(position, num, 2));
	readDWords = (position: number, num: number): number[] => (this.readBytes(position, num, 4));
	
	get position() {
		return this._position;
	}
}

export default WolfBuffer;
